package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;

public class Hematologists {

	private JFrame frame;
	private JTextField HematologistDoctors;
	private JTextField HematologistTime;
	private String HemaDoctor, HemaTime;
	static String HemaFinal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Hematologists window = new Hematologists();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Hematologists() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblHematologists = new JLabel("Hematologists:");
		lblHematologists.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblHematologists.setBounds(145, 11, 177, 23);
		panel.add(lblHematologists);
		
		JLabel label_1 = new JLabel("Pick a Doctor:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_1.setBounds(74, 84, 92, 14);
		panel.add(label_1);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selectedValue = comboBox.getSelectedItem().toString();
				HematologistDoctors.setText(selectedValue);
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Doctors:", "Dr. Carl Ackerson", "Dr. Chelsea Cheu", "Dr. Grant Eustis", "Dr. Macy Linamen", "Dr. Nicholas Stefano"}));
		comboBox.setBounds(176, 80, 170, 23);
		panel.add(comboBox);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selectedValue = comboBox_1.getSelectedItem().toString();
				HematologistTime.setText(selectedValue);
			}
		});
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Time:", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"}));
		comboBox_1.setBounds(176, 132, 170, 23);
		panel.add(comboBox_1);
		
		JLabel label_2 = new JLabel("Pick the Time:");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_2.setBounds(74, 136, 92, 14);
		panel.add(label_2);
		
		JButton button = new JButton("Back");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AppointmentsMenu.main(null);
				frame.setVisible(false);
			}
			
		});
		button.setBounds(145, 227, 89, 23);
		panel.add(button);
		
		JButton button_2 = new JButton("Home Page");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		button_2.setBounds(10, 227, 103, 23);
		panel.add(button_2);
		
		HematologistDoctors = new JTextField();
		HematologistDoctors.setEnabled(false);
		HematologistDoctors.setColumns(10);
		HematologistDoctors.setBounds(356, 80, 0, 0);
		panel.add(HematologistDoctors);
		
		HematologistTime = new JTextField();
		HematologistTime.setEnabled(false);
		HematologistTime.setColumns(10);
		HematologistTime.setBounds(356, 133, 0, 0);
		panel.add(HematologistTime);
		
		final JButton button_1 = new JButton("Save & Back to Home");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (HematologistDoctors.getText().isEmpty() || HematologistTime.getText().isEmpty()) {
					JOptionPane.showMessageDialog(button_1, "Caution: You Left A Blank Text Field");
				}
				else {
					HemaDoctor = HematologistDoctors.getText();
					HemaTime = HematologistTime.getText().trim();
					
					
					HemaFinal = (HemaDoctor) +(",") +(HemaTime); 
					String Data = Hematologists.HemaFinal;
					try {
						BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\Users\\Sameer\\eclipse-workspace\\login\\src\\final1\\Patient.txt"), true));
						reader.write(Data);
						reader.newLine();
						reader.close();
						System.out.println("Done");
					} catch (IOException E) {
						// TODO: handle exception
					}
					
					WelcomePage.main(null);
					frame.setVisible(false);
			}
			}
		});
		button_1.setBounds(268, 227, 156, 23);
		panel.add(button_1);
	}

}
