package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;

public class Gynaecologists {

	private JFrame frame;
	private JTextField GynaecologistDoctors;
	private JTextField GynaecologistTime;
	private String GynaDoctor, GynaTime;
	static String GynaFinal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Gynaecologists window = new Gynaecologists();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Gynaecologists() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblGynaecologists = new JLabel("Gynaecologists:");
		lblGynaecologists.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblGynaecologists.setBounds(161, 11, 159, 29);
		panel.add(lblGynaecologists);
		
		JButton button = new JButton("Home Page");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 227, 103, 23);
		panel.add(button);
		
		JLabel label = new JLabel("Pick a Doctor:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label.setBounds(64, 98, 92, 14);
		panel.add(label);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedValue = comboBox.getSelectedItem().toString();
				GynaecologistDoctors.setText(selectedValue);
				
				
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Doctors:", "Dr. Cristian Champion", "Dr. Haven Nestingen", "Dr. Kenneth Ryant", "Dr. Autumn Andel", "Dr. Blake Calhoon", "Dr. Doris Greenmyer"}));
		comboBox.setBounds(166, 94, 170, 23);
		panel.add(comboBox);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selectedValue = comboBox_1.getSelectedItem().toString();
				GynaecologistTime.setText(selectedValue);
			}
		});
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Time:", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"}));
		comboBox_1.setBounds(166, 146, 170, 23);
		panel.add(comboBox_1);
		
		JLabel label_1 = new JLabel("Pick the Time:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_1.setBounds(64, 150, 92, 14);
		panel.add(label_1);
		
		JButton button_2 = new JButton("Back");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AppointmentsMenu.main(null);
				frame.setVisible(false);
			}
		});
		button_2.setBounds(150, 227, 89, 23);
		panel.add(button_2);
		
		GynaecologistDoctors = new JTextField();
		GynaecologistDoctors.setEnabled(false);
		GynaecologistDoctors.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		GynaecologistDoctors.setBounds(338, 96, 0, 0);
		panel.add(GynaecologistDoctors);
		GynaecologistDoctors.setColumns(10);
		
		GynaecologistTime = new JTextField();
		GynaecologistTime.setEnabled(false);
		GynaecologistTime.setColumns(10);
		GynaecologistTime.setBounds(338, 147, 0, 0);
		panel.add(GynaecologistTime);
		
		final JButton button_1 = new JButton("Save & Back to Home");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (GynaecologistDoctors.getText().isEmpty() || GynaecologistTime.getText().isEmpty()) {
					JOptionPane.showMessageDialog(button_1, "Caution: You Left A Blank Text Field");
				}
				else {
					GynaDoctor = GynaecologistDoctors.getText();
					GynaTime = GynaecologistTime.getText().trim();
					
					
					GynaFinal = (GynaDoctor) +(",") +(GynaTime); 
					String Data = Gynaecologists.GynaFinal;
					try {
						BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\Users\\Sameer\\eclipse-workspace\\login\\src\\final1\\Patient.txt"), true));
						reader.write(Data);
						reader.newLine();
						reader.close();
						System.out.println("Done");
					} catch (IOException E) {
						// TODO: handle exception
					}
					
					WelcomePage.main(null);
					frame.setVisible(false);
			}}
			
		});
		button_1.setBounds(268, 227, 156, 23);
		panel.add(button_1);
	}
}
