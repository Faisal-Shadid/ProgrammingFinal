package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class MedicalInsurance {

	private JFrame frame;
	private String MedicalIns;
	static String MedicalInsFinal;
	private JTextField MedInsFld;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MedicalInsurance window = new MedicalInsurance();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MedicalInsurance() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblMedicalInsurance = new JLabel("Medical Insurance");
		lblMedicalInsurance.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblMedicalInsurance.setBounds(140, 11, 157, 32);
		panel.add(lblMedicalInsurance);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selectedValue = comboBox.getSelectedItem().toString();
				MedInsFld.setText(selectedValue);
			}
		});
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 16));
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Insurance Companies:", "GIG", "JEI", "JIC", "JOIF", "AICJ", "RHIM", "JERCO", "MEICPS", "JOFICO", "Medexa", "MetLife", "MedGulf", "NatHealth", "Jordan Care", "Med Service", "EuroArab Group", "MedNet Jordan", "Newton insurance", "Philadelphia Insurance Co"}));
		comboBox.setBounds(34, 115, 340, 39);
		panel.add(comboBox);
		
		JLabel lblPleaseSelectAn = new JLabel("Please Select an Insurance Company to add to the Patient:");
		lblPleaseSelectAn.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPleaseSelectAn.setBounds(34, 54, 340, 50);
		panel.add(lblPleaseSelectAn);
		
		JButton btnHomePage = new JButton("Home Page");
		btnHomePage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		btnHomePage.setBounds(10, 227, 122, 23);
		panel.add(btnHomePage);
		
		JButton btnSave = new JButton("Appointments");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (MedInsFld.getText().isEmpty() || MedInsFld.getText().equals("Insurance Companies:")) {
					JOptionPane.showMessageDialog(MedInsFld, "Please Select The Desired Company");
					
				}
				else {
					
				
				MedicalIns = MedInsFld.getText().trim();
				
				MedicalInsFinal = (",") +(MedicalIns) +(","); 
				String Data = MedicalInsurance.MedicalInsFinal;
				try {
					BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\\\Users\\\\Sameer\\\\eclipse-workspace\\\\login\\\\src\\\\final1\\\\Patient.txt"), true));
					reader.write(Data);
					reader.close();
					System.out.println("Done");
				} catch (IOException E) {
					// TODO: handle exception
				}
				
				
				
				AppointmentsMenu.main(null);
				frame.setVisible(false);
			}
			}
		});
		btnSave.setBounds(302, 227, 122, 23);
		panel.add(btnSave);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				NewPatient.main(null);
				frame.setVisible(false);
			}
		});
		btnBack.setBounds(180, 227, 89, 23);
		panel.add(btnBack);
		
		MedInsFld = new JTextField();
		MedInsFld.setBounds(34, 176, 0, 0);
		panel.add(MedInsFld);
		MedInsFld.setColumns(10);
	}

}
