package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JTextField;
import java.awt.SystemColor;
import java.awt.Color;

public class Urologist {

	private JFrame frame;
	private JTextField UrologistDoctors;
	private JTextField UrologistTime;
	private String UroloDoctor, UroloTime;
	static String UroloFinal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Urologist window = new Urologist();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Urologist() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblUrologist = new JLabel("Urologists:");
		lblUrologist.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblUrologist.setBounds(156, 11, 124, 20);
		panel.add(lblUrologist);
		
		JButton btnHomePage = new JButton("Home Page");
		btnHomePage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		btnHomePage.setBounds(10, 227, 103, 23);
		panel.add(btnHomePage);
		
		JButton btnNewButton = new JButton("Back");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AppointmentsMenu.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(156, 227, 89, 23);
		panel.add(btnNewButton);
		
		JLabel label = new JLabel("Pick a Doctor:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label.setBounds(70, 76, 92, 14);
		panel.add(label);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedValue = comboBox.getSelectedItem().toString();
				UrologistDoctors.setText(selectedValue);
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Doctors:", "Dr. Mohammad Amouri", "Dr. Laith Abu Al-Samen", "Dr. Farah Maraqa", "Dr. Rashed Hammouri", "Dr. Musab Al-Wawi", "Dr. Moheeb Mohammad"}));
		comboBox.setBounds(172, 72, 170, 23);
		panel.add(comboBox);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedValue = comboBox_1.getSelectedItem().toString();
				UrologistTime.setText(selectedValue);
			}
		});
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Time:", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"}));
		comboBox_1.setBounds(172, 124, 170, 23);
		panel.add(comboBox_1);
		
		JLabel label_1 = new JLabel("Pick the Time:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_1.setBounds(70, 128, 92, 14);
		panel.add(label_1);
		
		UrologistDoctors = new JTextField();
		UrologistDoctors.setEnabled(false);
		UrologistDoctors.setColumns(10);
		UrologistDoctors.setBounds(359, 74, 0, 0);
		panel.add(UrologistDoctors);
		
		UrologistTime = new JTextField();
		UrologistTime.setEnabled(false);
		UrologistTime.setColumns(10);
		UrologistTime.setBounds(359, 127, 0, 0);
		panel.add(UrologistTime);
		
		final JButton button = new JButton("Save & Back to Home");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (UrologistDoctors.getText().isEmpty() || UrologistTime.getText().isEmpty()) {
					JOptionPane.showMessageDialog(button, "Caution: You Left A Blank Text Field");
				}
				else {
					UroloDoctor = UrologistDoctors.getText();
					UroloTime = UrologistTime.getText().trim();
					
					
					UroloFinal = (UroloDoctor) +(",") +(UroloTime); 
					String Data = Urologist.UroloFinal;
					try {
						BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\Users\\Sameer\\eclipse-workspace\\login\\src\\final1\\Patient.txt"), true));
						reader.write(Data);
						reader.newLine();
						reader.close();
						System.out.println("Done");
					} catch (IOException E) {
						// TODO: handle exception
					}
					
					WelcomePage.main(null);
					frame.setVisible(false);
			}
			}
		});
		button.setBounds(268, 227, 156, 23);
		panel.add(button);
	}

}
