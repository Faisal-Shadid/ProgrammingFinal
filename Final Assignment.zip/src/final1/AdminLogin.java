package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class AdminLogin {

	private JFrame frame;
	private JTextField username;
	private JPasswordField password;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AdminLogin window = new AdminLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AdminLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		
		
		JLabel lblAdminLogin = new JLabel("Admin Login");
		lblAdminLogin.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblAdminLogin.setBounds(152, 11, 141, 20);
		panel.add(lblAdminLogin);
		
		username = new JTextField();
		username.setColumns(10);
		username.setBounds(174, 89, 141, 20);
		panel.add(username);
		
		JButton button = new JButton("Home Page");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 227, 102, 23);
		panel.add(button);
		
		JButton button_1 = new JButton("Back");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		button_1.setBounds(166, 227, 89, 23);
		panel.add(button_1);
		
		JButton button_2 = new JButton("Next");
		button_2.addActionListener(new ActionListener() {
			@SuppressWarnings("deprecation")
			public void actionPerformed(ActionEvent e) {
				String uname = username.getText();
				String pass = password.getText();
				
			      if (uname.equals("Admin") && pass.equals("Admin")) {
					   
					    AdminMenu.main(null);
						frame.setVisible(false);
					 
					}
					else {
						 JOptionPane.showMessageDialog(username, "Caution: You Left A Blank Text Field");
						 username.setText(null);
						 password.setText(null);
			
					}
					
				}
		});
		button_2.setBounds(335, 227, 89, 23);
		panel.add(button_2);
		
		JLabel lblAdminId = new JLabel("Admin ID");
		lblAdminId.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAdminId.setBounds(75, 88, 77, 20);
		panel.add(lblAdminId);
		
		JLabel label_2 = new JLabel("Password");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 14));
		label_2.setBounds(75, 138, 77, 23);
		panel.add(label_2);
		
		password = new JPasswordField();
		password.setBounds(174, 141, 141, 20);
		panel.add(password);
	}

}
