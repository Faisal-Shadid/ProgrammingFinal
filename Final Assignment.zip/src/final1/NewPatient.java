package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JTextField;

import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;

public class NewPatient {

	private JFrame frame;
	private JTextField NameFld;
	private JTextField AgeFld;
	private JTextField PhoneFld;
	private JTextField IDFld;
	private JTextField NationalityFld;
	private JTextField GenderFld;
	private String Name, NationalID, Age, Gender, PhoneNumber, Nationality;
	static String NPFinal;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					NewPatient window = new NewPatient();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public NewPatient() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnHomePage = new JButton("Home Page");
		btnHomePage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		btnHomePage.setBounds(10, 227, 111, 23);
		panel.add(btnHomePage);
		
		JLabel lblNewPatient = new JLabel("New Patient");
		lblNewPatient.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewPatient.setBounds(148, 11, 117, 23);
		panel.add(lblNewPatient);
		
		JLabel lblName = new JLabel("National ID:");
		lblName.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblName.setBounds(37, 75, 105, 23);
		panel.add(lblName);
		
		JLabel lblAge = new JLabel("Age:");
		lblAge.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblAge.setBounds(37, 121, 105, 23);
		panel.add(lblAge);
		
		JLabel lblGender = new JLabel("Gender:");
		lblGender.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblGender.setBounds(37, 174, 105, 14);
		panel.add(lblGender);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number:");
		lblPhoneNumber.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblPhoneNumber.setBounds(37, 149, 105, 14);
		panel.add(lblPhoneNumber);
		
		NameFld = new JTextField();
		NameFld.setBounds(170, 51, 141, 20);
		panel.add(NameFld);
		NameFld.setColumns(10);
		
		AgeFld = new JTextField();
		AgeFld.setBounds(170, 123, 141, 20);
		panel.add(AgeFld);
		AgeFld.setColumns(10);
		
		PhoneFld = new JTextField();
		PhoneFld.setBounds(170, 147, 141, 20);
		panel.add(PhoneFld);
		PhoneFld.setColumns(10);
		
		JButton btnSaveAndGo = new JButton("Medical Insurance");
		btnSaveAndGo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if ( NameFld.getText().isEmpty() || IDFld.getText().isEmpty() || NationalityFld.getText().isEmpty() || AgeFld.getText().isEmpty() || PhoneFld.getText().isEmpty() || GenderFld.getText().isEmpty() || GenderFld.getText().equals("Select Gender:") ) {
					 JOptionPane.showMessageDialog(NameFld, "Caution: You Left A Blank Text Field");
					    
				}
				else {
				
				Name = NameFld.getText();
				NationalID = IDFld.getText().trim();
				Nationality = NationalityFld.getText().trim();
				Age = AgeFld.getText().trim();
				PhoneNumber = PhoneFld.getText().trim();
				Gender = GenderFld.getText().trim();
				
				NPFinal = (Name) +(",") +(NationalID)+(",")+(Nationality)+(",")+(Age)+(",")+(PhoneNumber)+(",")+(Gender); 
				String Data = NewPatient.NPFinal;
				try {
					BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\Users\\Sameer\\eclipse-workspace\\login\\src\\final1\\Patient.txt"), true));
					reader.write(Data);
					reader.close();
					System.out.println("Done");
				} catch (IOException E) {
					// TODO: handle exception
				}
				
				
				MedicalInsurance.main(null);
				frame.setVisible(false);
			}
			}
		});
		btnSaveAndGo.setBounds(268, 227, 156, 23);
		panel.add(btnSaveAndGo);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				EmpMenu.main(null);
				frame.setVisible(false);
			}
		});
		btnBack.setBounds(159, 227, 67, 23);
		panel.add(btnBack);
		
		JLabel lblNewLabel = new JLabel("Name:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setBounds(37, 51, 46, 20);
		panel.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("Nationailty:");
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel_1.setBounds(37, 99, 84, 20);
		panel.add(lblNewLabel_1);
		
		IDFld = new JTextField();
		IDFld.setColumns(10);
		IDFld.setBounds(170, 75, 141, 20);
		panel.add(IDFld);
		
		NationalityFld = new JTextField();
		NationalityFld.setColumns(10);
		NationalityFld.setBounds(170, 99, 141, 20);
		panel.add(NationalityFld);
		
		final JComboBox<Object> comboBox = new JComboBox<Object>();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selectedValue = comboBox.getSelectedItem().toString();
				GenderFld.setText(selectedValue);
			}
		});
		comboBox.setModel(new DefaultComboBoxModel<Object>(new String[] {"Select Gender:", "Male", "Female"}));
		comboBox.setBounds(170, 172, 141, 23);
		panel.add(comboBox);
		
		GenderFld = new JTextField();
		GenderFld.setEnabled(false);
		GenderFld.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
			}
		});
		GenderFld.setBounds(424, 192, 0, 0);
		panel.add(GenderFld);
		GenderFld.setColumns(10);
	}
}
