package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;

public class Paediatricians {

	private JFrame frame;
	private JTextField PaediatricianDoctors;
	private JTextField PaediatricianTime;
	private String PaedDoctor, PaedTime;
	static String PaedFinal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Paediatricians window = new Paediatricians();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Paediatricians() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblPaediatricians = new JLabel("Paediatricians:");
		lblPaediatricians.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPaediatricians.setBounds(149, 11, 144, 29);
		panel.add(lblPaediatricians);
		
		JLabel label = new JLabel("Pick a Doctor:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label.setBounds(74, 74, 92, 14);
		panel.add(label);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedValue = comboBox.getSelectedItem().toString();
				PaediatricianDoctors.setText(selectedValue);
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Doctors:", "Dr. Abdulrahman Mreyan", "Dr. Ahmad Darwish", "Dr. Feras Obeid", "Dr. Kareem Marzouqah", "Dr. Moayad Talafha", "Dr. Aderlahman Khashan"}));
		comboBox.setBounds(176, 70, 170, 23);
		panel.add(comboBox);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedValue = comboBox_1.getSelectedItem().toString();
				PaediatricianTime.setText(selectedValue);
			}
		});
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Time:", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"}));
		comboBox_1.setBounds(176, 122, 170, 23);
		panel.add(comboBox_1);
		
		JLabel label_1 = new JLabel("Pick the Time:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_1.setBounds(74, 126, 92, 14);
		panel.add(label_1);
		
		final JButton button_1 = new JButton("Home Page");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		button_1.setBounds(10, 227, 103, 23);
		panel.add(button_1);
		
		JButton button_2 = new JButton("Back");
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AppointmentsMenu.main(null);
				frame.setVisible(false);
			}
		});
		button_2.setBounds(149, 227, 89, 23);
		panel.add(button_2);
		
		PaediatricianDoctors = new JTextField();
		PaediatricianDoctors.setEnabled(false);
		PaediatricianDoctors.setColumns(10);
		PaediatricianDoctors.setBounds(423, 92, 1, 0);
		panel.add(PaediatricianDoctors);
		
		PaediatricianTime = new JTextField();
		PaediatricianTime.setEnabled(false);
		PaediatricianTime.setColumns(10);
		PaediatricianTime.setBounds(423, 145, 1, 0);
		panel.add(PaediatricianTime);
		
		JButton button = new JButton("Save & Back to Home");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (PaediatricianTime.getText().isEmpty() || PaediatricianDoctors.getText().isEmpty()) {
					JOptionPane.showMessageDialog(button_1, "Caution: You Left A Blank Text Field");
				}
				else {
					PaedDoctor = PaediatricianDoctors.getText();
					PaedTime = PaediatricianTime.getText().trim();
					
					
					PaedFinal = (PaedDoctor) +(",") +(PaedTime); 
					String Data = Paediatricians.PaedFinal;
					try {
						BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\Users\\Sameer\\eclipse-workspace\\login\\src\\final1\\Patient.txt"), true));
						reader.write(Data);
						reader.newLine();
						reader.close();
						System.out.println("Done");
					} catch (IOException E) {
						// TODO: handle exception
					}
					
					WelcomePage.main(null);
					frame.setVisible(false);
			}
			}
		});
		button.setBounds(268, 227, 156, 23);
		panel.add(button);
	}

}
