package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.Color;

public class Neurologist {

	private JFrame frame;
	private JTextField NeurologistDoctors;
	private JTextField NeurologistTime;
	private String NeuroDoctor, NeuroTime;
	static String NeuroFinal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Neurologist window = new Neurologist();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Neurologist() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblNeurologist = new JLabel("Neurologists:");
		lblNeurologist.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNeurologist.setBounds(158, 11, 118, 30);
		panel.add(lblNeurologist);
		
		final JButton saveHome = new JButton("Save & Back to Home");
		saveHome.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (NeurologistTime.getText().isEmpty() || NeurologistDoctors.getText().isEmpty()) {
					JOptionPane.showMessageDialog(saveHome, "Caution: You Left A Blank Text Field");
				}
				else {
					NeuroDoctor = NeurologistDoctors.getText();
					NeuroTime = NeurologistTime.getText().trim();
					
					
					NeuroFinal = (NeuroDoctor) +(",") +(NeuroTime); 
					String Data = Neurologist.NeuroFinal;
					try {
						BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\Users\\Sameer\\eclipse-workspace\\login\\src\\final1\\Patient.txt"), true));
						reader.write(Data);
						reader.newLine();
						reader.close();
						System.out.println("Done");
					} catch (IOException E) {
						// TODO: handle exception
					}
					
					WelcomePage.main(null);
					frame.setVisible(false);
					
				}
			}
					
				
			
		});
		saveHome.setBounds(268, 227, 156, 23);
		panel.add(saveHome);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AppointmentsMenu.main(null);
				frame.setVisible(false);
			}
		});
		btnBack.setBounds(158, 227, 89, 23);
		panel.add(btnBack);
		
		JButton button = new JButton("Home Page");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 227, 103, 23);
		panel.add(button);
		
		JLabel label = new JLabel("Pick a Doctor:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label.setBounds(76, 92, 92, 14);
		panel.add(label);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String selectedValue = comboBox.getSelectedItem().toString();
				NeurologistDoctors.setText(selectedValue);
				
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Doctors:", "Dr. Faisal Shadid", "Dr. Abdelrahman Jaghoub", "Dr. Lynn Ibrahim", "Dr. Sabrine Abu-Sulaiman"}));
		comboBox.setBounds(178, 88, 170, 23);
		panel.add(comboBox);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				String selectedValue = comboBox_1.getSelectedItem().toString();
				NeurologistTime.setText(selectedValue);
			
			}
		});
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Time:", "8:00", "9:00", "10:00", "11:00", "12:00", "13:00", "14:00", "15:00", "16:00", "17:00", "18:00"}));
		comboBox_1.setBounds(178, 140, 170, 23);
		panel.add(comboBox_1);
		
		JLabel label_1 = new JLabel("Pick the Time:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_1.setBounds(76, 144, 92, 14);
		panel.add(label_1);
		
		NeurologistDoctors = new JTextField();
		NeurologistDoctors.setEnabled(false);
		NeurologistDoctors.setColumns(10);
		NeurologistDoctors.setBounds(425, 109, 0, 0);
		panel.add(NeurologistDoctors);
		
		NeurologistTime = new JTextField();
		NeurologistTime.setEnabled(false);
		NeurologistTime.setColumns(10);
		NeurologistTime.setBounds(425, 162, 0, 0);
		panel.add(NeurologistTime);
	}

}
