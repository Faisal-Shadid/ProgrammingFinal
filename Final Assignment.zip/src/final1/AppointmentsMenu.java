package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import java.awt.Component;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import java.awt.event.ItemListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ItemEvent;
import java.awt.Color;

public class AppointmentsMenu {

	private JFrame frame;
	private JTextField txtFld;
	private JTextField DayFld;
	private JTextField MonthFld;
	private JTextField YearFld;
	private String Day, Month, Year;
	static String Date;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AppointmentsMenu window = new AppointmentsMenu();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AppointmentsMenu() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblAppointments = new JLabel("Appointments");
		lblAppointments.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblAppointments.setBounds(143, 11, 125, 29);
		panel.add(lblAppointments);
		
		JButton btnHomePage = new JButton("Home Page");
		btnHomePage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		btnHomePage.setBounds(10, 227, 114, 23);
		panel.add(btnHomePage);
		
		JButton btnSave = new JButton("Next");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				if (txtFld.getText().equals("0") || txtFld.getText().equals(null)) {
					
					JOptionPane.showMessageDialog(txtFld, "Caution: You Left A Blank Option");
					writeOnFile();
					
					}
				else if (txtFld.getText().equals("1")) {	
					writeOnFile();
					
					
					Anaesthesiologists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("2")) {
					writeOnFile();
					
					
					Cardiologist.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("3")) {
					writeOnFile();
					
					
					Dentists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("4")) {
					writeOnFile();
					
					
					Dermatologists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("5")) {
					writeOnFile();
					
					
					DiagnosticRadiologists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("6")) {
					writeOnFile();
					
					
					GeneralSurgeons.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("7")) {
					writeOnFile();
					
					
					Gynaecologists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("8")) {
					writeOnFile();
					
					
					Hematologists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("9")) {
					writeOnFile();
					
					
					Internists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("10")) {
					writeOnFile();
					
					
					Neurologist.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("11")) {
					writeOnFile();
					
					
					Ophthalmologists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("12")) {
					writeOnFile();
					
					
					Otolarynologists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("13")) {
					writeOnFile();
					
					
					Paediatricians.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("14")) {
					writeOnFile();
					
					
					Pharmacologists.main(null);
					frame.setVisible(false);
				} else if (txtFld.getText().equals("15")) {
					writeOnFile();
					
					
					Urologist.main(null);
					frame.setVisible(false);
				} else {
					Object textField = null;
					JOptionPane.showMessageDialog((Component) textField, "Please Select The Speciality");
				}
			}

			private void writeOnFile() {
				Day = DayFld.getText().trim();
				Month = MonthFld.getText().trim();
				Year= YearFld.getText().trim();
				

Date = (Day)+(",")+(Month)+(",")+(Year)+(","); 
String Data = AppointmentsMenu.Date;
try {
				BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\Users\\Sameer\\eclipse-workspace\\login\\src\\final1\\Patient.txt"), true));
				reader.write(Data);
				reader.close();
				System.out.println("Done");
} catch (IOException E) {
				// TODO: handle exception
}
			}
		});
		btnSave.setBounds(335, 227, 89, 23);
		panel.add(btnSave);
		
		final JComboBox comboBox = new JComboBox();
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				setToTextFld();
			}

			private void setToTextFld() {
				//This puts a number in the text field
				int speciality = comboBox.getSelectedIndex();
				txtFld.setText(String.valueOf(speciality));
				// TODO Auto-generated method stub
				
			}
		});
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
			}
		});
		comboBox.setFont(new Font("Tahoma", Font.BOLD, 14));
		comboBox.setMaximumRowCount(6);
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Pick a Speciality:", "Anaesthesiologists ", "Cardiologist ", "Dentists ", "Dermatologists ", "Diagnostic Radiologists", "General Surgeons", "Gynaecologists ", "Hematologists", "Internists ", "Neurologist ", "Ophthalmologists ", "Otolarynologists ", "Paediatricians ", "Pharmacologist", "Urologist"}));
		comboBox.setBounds(78, 51, 256, 29);
		panel.add(comboBox);
		
		JLabel lblDay = new JLabel("Day:");
		lblDay.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblDay.setBounds(78, 94, 46, 14);
		panel.add(lblDay);
		
		JLabel lblMonth = new JLabel("Month:");
		lblMonth.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblMonth.setBounds(78, 138, 46, 14);
		panel.add(lblMonth);
		
		JLabel lblYear = new JLabel("Year:");
		lblYear.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblYear.setBounds(78, 181, 46, 14);
		panel.add(lblYear);
		
		final JComboBox comboBox_1 = new JComboBox();
		comboBox_1.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent arg0) {
				String selectedValue = comboBox_1.getSelectedItem().toString();
				DayFld.setText(selectedValue);
			
			
			}
		});
		comboBox_1.setModel(new DefaultComboBoxModel(new String[] {"Pick a Day:", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"}));
		comboBox_1.setBounds(127, 91, 207, 23);
		panel.add(comboBox_1);
		
		final JComboBox comboBox_2 = new JComboBox();
		comboBox_2.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String selectedValue = comboBox_2.getSelectedItem().toString();
				MonthFld.setText(selectedValue);
			
			}
		});
		comboBox_2.setModel(new DefaultComboBoxModel(new String[] {"Pick a Month:", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"}));
		comboBox_2.setBounds(127, 135, 207, 23);
		panel.add(comboBox_2);
		
		final JComboBox comboBox_3 = new JComboBox();
		comboBox_3.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {
				String selectedValue = comboBox_3.getSelectedItem().toString();
				YearFld.setText(selectedValue);
			
			}
		});
		comboBox_3.setModel(new DefaultComboBoxModel(new String[] {"Pick a Year:", "2020", "2021", "2022", "2023", "2024", "2025"}));
		comboBox_3.setBounds(127, 173, 207, 23);
		panel.add(comboBox_3);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				MedicalInsurance.main(null);
				frame.setVisible(false);
			}
		});
		btnBack.setBounds(168, 227, 89, 23);
		panel.add(btnBack);
		
		txtFld = new JTextField();
		txtFld.setEnabled(false);
		txtFld.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		txtFld.setBounds(430, 77, 0, 0);
		panel.add(txtFld);
		txtFld.setColumns(10);
		
		DayFld = new JTextField();
		DayFld.setEnabled(false);
		DayFld.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		DayFld.setColumns(10);
		DayFld.setBounds(344, 89, 0, 0);
		panel.add(DayFld);
		
		MonthFld = new JTextField();
		MonthFld.setEnabled(false);
		MonthFld.setColumns(10);
		MonthFld.setBounds(344, 132, 0, 0);
		panel.add(MonthFld);
		
		YearFld = new JTextField();
		YearFld.setEnabled(false);
		YearFld.setColumns(10);
		YearFld.setBounds(344, 175, 0, 0);
		panel.add(YearFld);
	}
}
