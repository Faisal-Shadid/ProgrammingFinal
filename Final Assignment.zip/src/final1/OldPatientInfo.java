package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class OldPatientInfo {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					OldPatientInfo window = new OldPatientInfo();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public OldPatientInfo() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JButton btnHomePage = new JButton("Home Page");
		btnHomePage.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		btnHomePage.setBounds(10, 227, 102, 23);
		panel.add(btnHomePage);
		
		JLabel lblOldPatientsInformation = new JLabel("Old Patient's Information");
		lblOldPatientsInformation.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblOldPatientsInformation.setBounds(101, 11, 213, 34);
		panel.add(lblOldPatientsInformation);
		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				EmpMenu.main(null);
				frame.setVisible(false);
}
		});
		btnBack.setBounds(143, 227, 89, 23);
		panel.add(btnBack);
		
		JLabel lblPleaseWaitIn = new JLabel("Please wait in the Waiting Area after giving us your ID");
		lblPleaseWaitIn.setFont(new Font("Tahoma", Font.BOLD, 13));
		lblPleaseWaitIn.setBounds(29, 92, 373, 48);
		panel.add(lblPleaseWaitIn);
		
		JLabel lblYourInformationWill = new JLabel("Your Information will be out Shortly :)");
		lblYourInformationWill.setFont(new Font("Tahoma", Font.ITALIC, 14));
		lblYourInformationWill.setBounds(88, 135, 241, 40);
		panel.add(lblYourInformationWill);
	}
}
