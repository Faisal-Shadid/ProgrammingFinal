package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.JRadioButton;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.awt.event.ActionEvent;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import java.awt.Color;

public class AddNewEmployees {

	private JFrame frame;
	private JTextField EmpPhoneNumber;
	private JTextField EmpAge;
	private JTextField EmpName;
	private JTextField EmpNationality;
	private JTextField EmpId;
	private JTextField GenderFld1;
	private String EmployeeName, EmployeeID, EmployeeAge, EmployeeGender, EmployeePhoneNumber, EmployeeNationality;
	static String EmpFinal;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					AddNewEmployees window = new AddNewEmployees();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public AddNewEmployees() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		EmpPhoneNumber = new JTextField();
		EmpPhoneNumber.setColumns(10);
		EmpPhoneNumber.setBounds(203, 151, 141, 20);
		panel.add(EmpPhoneNumber);
		
		EmpAge = new JTextField();
		EmpAge.setColumns(10);
		EmpAge.setBounds(203, 79, 141, 20);
		panel.add(EmpAge);
		
		EmpName = new JTextField();
		EmpName.setColumns(10);
		EmpName.setBounds(203, 55, 141, 20);
		panel.add(EmpName);
		
		JLabel label = new JLabel("Name:");
		label.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label.setBounds(23, 57, 152, 14);
		panel.add(label);
		
		JLabel label_1 = new JLabel("Age:");
		label_1.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_1.setBounds(23, 78, 152, 20);
		panel.add(label_1);
		
		JLabel label_2 = new JLabel("Phone Number:");
		label_2.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_2.setBounds(23, 153, 152, 18);
		panel.add(label_2);
		
		JLabel label_3 = new JLabel("Gender:");
		label_3.setFont(new Font("Tahoma", Font.PLAIN, 13));
		label_3.setBounds(23, 178, 152, 20);
		panel.add(label_3);
		JButton button = new JButton("Home Page");
		button.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		button.setBounds(10, 227, 111, 23);
		panel.add(button);
		
		JButton button_1 = new JButton("Back");
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				AdminMenu.main(null);
				frame.setVisible(false);
			}
		});
		button_1.setBounds(142, 227, 78, 23);
		panel.add(button_1);
		
		JLabel lblNewEmployee = new JLabel("New Employee");
		lblNewEmployee.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewEmployee.setBounds(160, 11, 141, 23);
		panel.add(lblNewEmployee);
		
		JLabel lblEmployeeId = new JLabel("Employee ID:");
		lblEmployeeId.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblEmployeeId.setBounds(23, 102, 152, 20);
		panel.add(lblEmployeeId);
		
		EmpNationality = new JTextField();
		EmpNationality.setColumns(10);
		EmpNationality.setBounds(203, 127, 141, 20);
		panel.add(EmpNationality);
		
		EmpId = new JTextField();
		EmpId.setColumns(10);
		EmpId.setBounds(203, 103, 141, 20);
		panel.add(EmpId);
		
		JLabel lblEmployeesNewPassword = new JLabel("Nationality:");
		lblEmployeesNewPassword.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblEmployeesNewPassword.setBounds(23, 129, 170, 14);
		panel.add(lblEmployeesNewPassword);
		
		JButton btnSave = new JButton("Save & go Back Home");
		btnSave.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (EmpPhoneNumber.getText().isEmpty() || EmpAge.getText().isEmpty()|| EmpNationality.getText().isEmpty() || EmpId.getText().isEmpty()  || GenderFld1.getText().isEmpty() || EmpName.getText().isEmpty()) {
				    JOptionPane.showMessageDialog(EmpPhoneNumber, "Caution: You Left A Blank Text Field");
				    
				}
				else {
				
					EmployeeName = EmpName.getText();
					EmployeeID = EmpId.getText().trim();
					EmployeeNationality = EmpNationality.getText().trim();
					EmployeeAge = EmpAge.getText().trim();
					EmployeePhoneNumber = EmpPhoneNumber.getText().trim();
					EmployeeGender = GenderFld1.getText().trim();
				
				EmpFinal = (EmployeeName) +(",") +(EmployeeID)+(",")+(EmployeeNationality)+(",")+(EmployeeAge)+(",")+(EmployeePhoneNumber)+(",")+(EmployeeGender); 
				String Data = AddNewEmployees.EmpFinal;
				try {
					BufferedWriter reader = new BufferedWriter(new FileWriter(new File("C:\\Users\\Sameer\\eclipse-workspace\\login\\src\\final1\\Employees.txt"), true));
					reader.write(Data);
					reader.close();
					System.out.println("Done");
				} catch (IOException E) {
					// TODO: handle exception
				}
				
				
				WelcomePage.main(null);
				frame.setVisible(false);
			}
			}
		});
		btnSave.setBounds(241, 227, 183, 23);
		panel.add(btnSave);
		
		final JComboBox<Object> comboBox = new JComboBox<Object>();
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String selectedValue = comboBox.getSelectedItem().toString();
				GenderFld1.setText(selectedValue);
			
			}
		});
		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Select Gender:", "Male", "Female"}));
		comboBox.setBounds(203, 174, 141, 23);
		panel.add(comboBox);
		
		GenderFld1 = new JTextField();
		GenderFld1.setEnabled(false);
		GenderFld1.setBounds(395, 199, 0, 0);
		panel.add(GenderFld1);
		GenderFld1.setColumns(10);
	}
}
