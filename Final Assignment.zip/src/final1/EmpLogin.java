package final1;

import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.BorderLayout;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import javax.swing.JPasswordField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;

public class EmpLogin {

	private JFrame frame;
	private JTextField usernametxt;
	private JPasswordField passwordtxt;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					EmpLogin window = new EmpLogin();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public EmpLogin() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Ministry of Health");
		frame.setBounds(100, 100, 450, 300);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.setLocationRelativeTo(null);
		JPanel panel = new JPanel();
		panel.setBackground(new Color(222, 184, 135));
		frame.getContentPane().add(panel, BorderLayout.CENTER);
		panel.setLayout(null);
		
		JLabel lblEmployeeLogin = new JLabel("Employee Login");
		lblEmployeeLogin.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblEmployeeLogin.setBounds(134, 11, 141, 20);
		panel.add(lblEmployeeLogin);
		
		usernametxt = new JTextField();
		usernametxt.setBounds(174, 89, 141, 20);
		panel.add(usernametxt);
		usernametxt.setColumns(10);
		
		
		JButton btnNewButton = new JButton("Home Page");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton.setBounds(10, 227, 102, 23);
		panel.add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Back");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				WelcomePage.main(null);
				frame.setVisible(false);
			}
		});
		btnNewButton_1.setBounds(166, 227, 89, 23);
		panel.add(btnNewButton_1);
		
		JButton btnNext = new JButton("Next");
		btnNext.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				String uname = usernametxt.getText();
				@SuppressWarnings("deprecation")
				String pass = passwordtxt.getText();
				
			      if (uname.equals("Employee") && pass.equals("123")) {
					   
			    	  EmpMenu.main(null);
						frame.setVisible(false);
					 
					}
					else {
						 JOptionPane.showMessageDialog(usernametxt, "Caution: You Left A Blank Text Field");
						 usernametxt.setText(null);
						 passwordtxt.setText(null);
					
				}
			// i added all those "//" to keep it from popping out a message every time i try to test my system, the "//" will be removed as soon as the system is ready for the final testing	
			}
		});
		btnNext.setBounds(335, 227, 89, 23);
		panel.add(btnNext);
		
		JLabel lblNewLabel = new JLabel("Employee ID");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 13));
		lblNewLabel.setBounds(75, 88, 77, 20);
		panel.add(lblNewLabel);
		
		JLabel lblPassword = new JLabel("Password");
		lblPassword.setFont(new Font("Tahoma", Font.PLAIN, 14));
		lblPassword.setBounds(75, 138, 77, 23);
		panel.add(lblPassword);
		
		passwordtxt = new JPasswordField();
		passwordtxt.setBounds(174, 141, 141, 20);
		panel.add(passwordtxt);
	}
}
